"""Internal code that is used by keywords in QWeb.keyword.*"""
